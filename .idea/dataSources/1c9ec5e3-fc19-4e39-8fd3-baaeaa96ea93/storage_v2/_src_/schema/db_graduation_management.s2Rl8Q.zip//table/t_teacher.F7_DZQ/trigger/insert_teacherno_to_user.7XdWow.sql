create definer = root@localhost trigger insert_teacherNo_to_user
    after insert
    on t_teacher
    for each row
BEGIN
INSERT INTO t_user VALUES(null,NEW.teacherNo,'666666',2);
END;

