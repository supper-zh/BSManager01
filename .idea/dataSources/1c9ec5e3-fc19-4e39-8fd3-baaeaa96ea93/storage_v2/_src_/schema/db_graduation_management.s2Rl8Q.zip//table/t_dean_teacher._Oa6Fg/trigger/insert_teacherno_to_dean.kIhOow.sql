create definer = root@localhost trigger insert_teacherNo_to_dean
    after insert
    on t_dean_teacher
    for each row
BEGIN
INSERT INTO t_user VALUES(null,NEW.teacherNo,'666666',0);
END;

