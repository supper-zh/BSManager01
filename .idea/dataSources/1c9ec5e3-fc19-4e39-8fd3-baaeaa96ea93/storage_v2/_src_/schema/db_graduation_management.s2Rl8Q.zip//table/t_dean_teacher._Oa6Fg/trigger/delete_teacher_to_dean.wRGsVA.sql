create definer = root@localhost trigger delete_teacher_to_dean
    after delete
    on t_dean_teacher
    for each row
BEGIN 
 DELETE FROM t_user WHERE userNo=OLD.teacherNo;
END;

