create definer = root@localhost trigger delete_admin_to_user
    after delete
    on t_admin
    for each row
BEGIN 
 DELETE FROM t_user WHERE userNo=OLD.adminNo;
END;

