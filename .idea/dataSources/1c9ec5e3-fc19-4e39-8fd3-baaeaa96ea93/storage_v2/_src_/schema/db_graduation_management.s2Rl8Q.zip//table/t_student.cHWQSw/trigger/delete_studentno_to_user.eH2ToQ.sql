create definer = root@localhost trigger delete_studentNo_to_user
    after delete
    on t_student
    for each row
BEGIN
DELETE FROM t_user WHERE userNo=OLD.studentNo;
END;

