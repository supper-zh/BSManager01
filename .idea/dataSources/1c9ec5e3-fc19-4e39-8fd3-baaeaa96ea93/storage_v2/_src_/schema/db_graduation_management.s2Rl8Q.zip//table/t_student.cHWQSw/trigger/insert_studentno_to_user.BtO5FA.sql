create definer = root@localhost trigger insert_studentNo_to_user
    after insert
    on t_student
    for each row
BEGIN
INSERT INTO t_user VALUES(null,NEW.studentNo,'666666',1);
END;

